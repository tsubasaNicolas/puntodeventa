

<select  class="selector" id="country" name="departamento" >
    <label for="">Departamento</label>
           <option value="australia">Seleccione</option>
    @foreach($departamentos as $departamento)
           <option value="{{$departamento->id}}">
      {{$departamento->nombredepartamento}}
           </option>
    @endforeach
</select>


<div
style="display: flex;justify-content: space-between;align-items: center;">
Departamento<input value="{{$producto->departamento}}"  name="departamento" 
type="text" class="inputglobal"></div>

